from enum import Enum, auto


class Special(Enum):
    INT = 47
    STRING = "SPECIAL"
    TUPLE = (1, -1)


print(Special.INT.value)
print(Special.TUPLE.value)

for i, name in enumerate(Special):
    print(i, name, name.value)


def type_checker(sp):
    match (sp):
        case Special.INT:
            print("I am an INTEGER")
        case Special.STRING:
            print("I am a STRING")
        case Special.TUPLE:
            print("I am a TUPLE", sp.value)


type_checker(Special.INT)
type_checker(Special.STRING)
type_checker(Special.TUPLE)