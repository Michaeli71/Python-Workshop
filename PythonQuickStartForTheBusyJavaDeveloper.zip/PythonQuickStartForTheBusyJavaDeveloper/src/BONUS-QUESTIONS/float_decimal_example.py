from decimal import Decimal

from decimal import *

one_sventh = Decimal(1) / Decimal(7)
print(one_sventh)

one_half = Decimal(0.5)
print(one_half)

one_tenth = Decimal(0.1)
print(one_tenth)

one_tenth = Decimal('0.1')
print(one_tenth)

value1 = 10.815
print(value1)
print(round(value1, 2))  # ups

value2 = Decimal(10.815)
print(value2)

value2 = Decimal('10.815')
print(value2)
print(round(value2, 2))


myothercontext = Context(prec=60, rounding=ROUND_HALF_DOWN)
setcontext(myothercontext)
print(Decimal(1) / Decimal(7))
# Decimal('0.142857142857142857142857142857142857142857142857142857142857')

myothercontext = Context(prec=250, rounding=ROUND_HALF_DOWN)
setcontext(myothercontext)
print(Decimal(1) / Decimal(7))
