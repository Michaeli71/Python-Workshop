import math

big = 2 ** 100
print(big)

big = 2 ** 500
print(big)

big_float = 2.5 * 1000_00_000_000 * 3.141529 * 1.111111111
print(big_float)

# float surpirse
val = 0.1
print(val)

val = 0.1 + 0.1 + 0.1

if val == 0.3:
    print("val == 0.3")
else:
    print("val != 0.3")
    print(val)

if math.isclose(val,0.3):
    print("val == 0.3")
else:
    print("val != 0.3")
    print(val)


# 15 Nachkommastellen
num = 1.23456789012345
print(num)

num = 1.234567890123456
print(f'{num:.17}') # auf nächste verfügbare Zahl gerundet

num = 1.234567890123456
print(f'{num:.30}')

print(big_float * 1000)
print(big_float * 1_000_000)

import sys
print(sys.float_info)

# -1.7976931348623157e+308 <= float <= 1.7976931348623157e+308
print(sys.float_info.max)
print(sys.float_info.min)