val1, val2, val3 = [1, 2, 3]
print(val1, val2, val3)

# Tuple Unpacking
val1, val2, val3 = (3, 1, 2)
print(val1, val2, val3)

val1, val2, val3, *others = [1, 2, 3, 4, 5,]
print(val1, val2, val3, others)

# Tuple Packing
packed = 1, 2, 3
print(packed)

# Shortest swap
first = "first"
second = "second"
first, second = second, first
print(first, second)