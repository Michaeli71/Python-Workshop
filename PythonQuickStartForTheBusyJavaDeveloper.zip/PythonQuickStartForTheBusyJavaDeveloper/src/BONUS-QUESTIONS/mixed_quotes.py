str1 = "DOUBLE 'contains' single"
str2 = 'SINGLE "contains" double'
str3 = "DOUBLE 'contains' single" + 'SINGLE "contains" double'

print("str1 =", str1)
print("str2 =", str2)
print("str1 + str2 =", str1 + " --- " + str2)
print("str1 + str2 =", str1 + str2)
print("str3 =", str3)