values = [0, 4.2, 27, 42.195, 7, 2]

# Mix von int und float ist erlaubt
values.sort()
print(values)

values += ["ONE", "TWO", "THREE", "FOUR"]

#values.sort() # TypeError: '<' not supported between instances of 'str' and 'float'
# print(values)


class Car:
    def __init__(self, brand, color, horse_power):
        self.brand = brand
        self.color = color
        self.horse_power = horse_power

    def __str__(self):
        return f"Marke: {self.brand} / Farbe: {self.color} /" + \
            f" PS: {self.horse_power}"

    def __repr__(self):
        return self.__str__()

    def paint_with(self, new_color):
        self.color = new_color

    def apply_tuning_kit(self):
        self.horse_power += 150

    def __eq__(self, other):
        if not isinstance(other, Car):
            return False

        return self.brand == other.brand and \
            self.color == other.color and \
            self.horse_power == other.horse_power

    def __lt__(self, other):
        if not isinstance(other, Car):
            return False
        return self.brand < other.brand or \
            (self.brand == other.brand and self.color < other.color or
             (self.color == other.color and self.horse_power < other.horse_power))


values = [
    Car("VW", "BLUE", 200),
    Car("VW", "RED", 100),
    Car("VW", "RED", 500),
    Car("BMW", "BLACK", 500)]
values.sort()
print(values)
