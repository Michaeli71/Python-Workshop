one_billion1 = 1000000000
one_billion2 = 1_000_000_000

ten_billion1 = 10000000000
ten_billion2 = 10_000_000_000

############### binary

binary_value1 = 0b0000111100001111
binary_value2 = 0b0000_1111_0000_1111

print("binary_value1", binary_value1)
print("ten_billion2", ten_billion2)

############### octal / hex

print(0o1, 0o11, 0o111)
print(0x1234CAFEBABE)
