
for i in range (2, 7):
    print("Loop", i)

    for j in range(1, 4):
        print("j", j)

        if i % 2 == 0 and j == 1:
            print("EVEN and j == 1")
            break

    if i == 5:
        print("END at 5")
        break


print("------------------------------------")

def print_count_down_rec(value):
    # rekursiver Abbruch
    if value <= 0:
        print("FINISH")
        return

    print(value)
    # rekursiver Abstieg
    print_count_down_rec(value - 1)


print_count_down_rec(3)


