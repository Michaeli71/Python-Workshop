from functools import reduce
from itertools import accumulate

values = [1, 2, 3, 4, 5, 6]

# Fakultät
result = reduce(lambda x, y: x * y, values)
print(result)

# Summe
result = reduce(lambda x, y: x + y, values)
print(result)

# Potenz
result = reduce(lambda x, y: x ** 2 + y ** 2, values)
print(result)

# Pair extraktion
pair_values = [(1, 2), (3, 4), (5, 6)]
result = reduce(lambda x, y: x + max(y), pair_values, 0)
print("1:", result)

result = reduce(lambda x, y: x + min(y), pair_values, 0)
print("2:", result)


##########################################################

values = [1, 2, 3, 4, 5, 6]

# Minimum
print("Minimum", reduce(lambda a, b: a if a < b else b, values))

# Maximum
print("Maximum", reduce(lambda a, b: a if a > b else b, values))

def my_add(a, b):
    result = a + b
    print(f"{a} + {b} = {result}")
    return result

reduce(my_add, values)

reduce(my_add, pair_values)


result = accumulate(pair_values, lambda x, y: x + y)
print("3:", list(result))




###########################################################

origi = [1, 2, 3, 4, 5, 6, 7]
filtered_values = filter(lambda x: x >= 3, origi)
print(filtered_values)
print(list(filtered_values))

def triple_it(x):
    return x * 3

origi = [1, 2, 3, 4, 5, 6, 7]
mapped_values = map(triple_it, origi)
print(mapped_values)
print(list(mapped_values))

mapped_values = [x + x for x in origi]
print(mapped_values)