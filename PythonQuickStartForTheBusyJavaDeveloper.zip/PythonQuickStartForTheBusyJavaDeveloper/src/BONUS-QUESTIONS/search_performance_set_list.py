import time

lots_of_values = [i for i in range(1, 1_000_000_000)]
values_as_set = set(lots_of_values)

print(lots_of_values[10:20])

# Suche in Liste
start = time.process_time()
print("999_999_999", 999_999_999 in lots_of_values)
end = time.process_time()
print("list() took %.2f ms" % ((end - start) * 1000))

# Suche in Set
start = time.process_time()
print("999_999_999", 999_999_999 in values_as_set)
end = time.process_time()
print("set() took %.2f ms" % ((end - start) * 1000))
