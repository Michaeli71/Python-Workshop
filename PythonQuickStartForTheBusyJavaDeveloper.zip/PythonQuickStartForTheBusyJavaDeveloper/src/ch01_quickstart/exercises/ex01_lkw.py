bestellmenge = 1_000

# TODO

