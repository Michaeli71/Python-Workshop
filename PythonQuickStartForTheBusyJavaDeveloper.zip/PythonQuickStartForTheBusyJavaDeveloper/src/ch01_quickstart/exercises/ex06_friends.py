def calc_friends(max_exclusive):
    friends = {}

    # TODO

    return friends


print(calc_friends(1000))