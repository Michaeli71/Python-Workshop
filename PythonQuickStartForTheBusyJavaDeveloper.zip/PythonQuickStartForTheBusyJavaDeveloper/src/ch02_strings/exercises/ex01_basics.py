nachricht = "Hallo lieber Workshop-Teilnehmer! Viel Spaß mit Python!"

# TODO