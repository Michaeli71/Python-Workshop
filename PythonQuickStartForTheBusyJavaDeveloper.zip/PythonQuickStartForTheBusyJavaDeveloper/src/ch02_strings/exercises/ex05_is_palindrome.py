def is_palindrome(input):
    # TODO
    pass


print(is_palindrome("AbBa"))
print(is_palindrome("Michael"))
print(is_palindrome("was it a car or a cat i saw".replace(" ", "")))