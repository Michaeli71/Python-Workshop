def remove_duplicates(input):
    result = ""

    # TODO

    return result


print(remove_duplicates("lalamlam"))
print(remove_duplicates("bananas"))