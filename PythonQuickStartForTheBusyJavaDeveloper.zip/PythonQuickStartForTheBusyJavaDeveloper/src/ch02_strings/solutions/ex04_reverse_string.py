def reverse_string(input):
    # rekursiver Abbruch
    if len(input) <= 1:
        return input

    first_char = input[0]
    remaining = input[1:]

    # rekursiver Abstieg
    return reverse_string(remaining) + first_char


print(reverse_string("ABCDEFGHI"))
print(reverse_string("was it a car or a cat i saw"))

print("ABCDEFGHI"[::-1])


# HOLY MOLY ... index
def reverse_string_v2(input):
    result = ""

    for idx in range(len(input) -1, -1, -1):
        result += input[idx]

    return result

print(reverse_string_v2("ABCDEFGHI"))


# nicer, aber ungünstig für Performance
def reverse_string_v3(input):
    result = []
    for char in input:
        result.insert(0, char)

    return "".join(result)

print(reverse_string_v3("ABCDEFGHI"))


