def is_palindrome(input):
    left = 0
    right = len(input) - 1
    lower_input = input.lower()
    is_same_char = True
    while left < right and is_same_char:
        is_same_char = (lower_input[left] == lower_input[right])
        left += 1
        right -= 1
    return is_same_char


print("-" * 10 + "ITERATIVE" + "-" * 10)
print("AbBa", is_palindrome("AbBa"))
print("Michael", is_palindrome("Michael"))
print("was it a car or a cat i saw", is_palindrome("was it a car or a cat i saw".replace(" ", "")))


###############


def is_palindrome_rec(input):
    if len(input) <= 0:
        return True

    if len(input) == 1:
        return True

    if input[0].lower() == input[-1].lower():
        # print(input[1:-1])
        return is_palindrome_rec(input[1:-1])

    return False


print("-" * 10 + "REC" + "-" * 10)
print("AbBa", is_palindrome_rec("AbBa"))
print("DrehMalAmHerd", is_palindrome_rec("DrehMalAmHerd"))
print("Michael", is_palindrome_rec("Michael"))



def is_palindrome_improved(input):
    left = 0
    right = len(input) - 1
    lower_input = input.lower()

    is_same_char = True
    while left < right and is_same_char:
        # skip invalid from left + right
        while is_skippable_char(left, lower_input):
            left += 1
        while is_skippable_char(right, lower_input):
            right -= 1

        if left < right:
            is_same_char = (lower_input[left] == lower_input[right])
            left += 1
            right -= 1

    return is_same_char


def is_skippable_char(idx, text):
    return text[idx] in " ,.!$#_"



print("-" * 10 + "IMPROVED" + "-" * 10)
print("AbBa", is_palindrome_improved("AbBa"))
print("Michael", is_palindrome_improved("Michael"))
print("was it a car or a cat i saw", is_palindrome_improved("was it a car or a cat i saw"))
print("Dreh#Mal$Am Herd!", is_palindrome_improved("Dreh#Mal$Am Herd!"))