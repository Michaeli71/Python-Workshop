class Counter:
    def __init__(self, count):
        self.count = count


def main():
    # Counter erzeugen, 2x hochzählen und dann resetten
    cnt = Counter(2)

    # TODO


if __name__ == "__main__":
    main()