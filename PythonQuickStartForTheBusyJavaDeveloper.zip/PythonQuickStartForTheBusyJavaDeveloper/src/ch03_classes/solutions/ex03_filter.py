class ExcludeFilter:
    def __init__(self, blocked=[]):
        self.__blocked = blocked

    def filter(self, values):
        return [x for x in values if x not in self.__blocked]


class IncludeFilter:
    def __init__(self, included=[]):
        self.__included = included

    def filter(self, values):
        return [x for x in values if x in self.__included]


class SPAMFilter(ExcludeFilter):
    def __init__(self, blocked=[]):
        super().__init__(blocked)


class NameFilter(IncludeFilter):
    def __init__(self, values_to_be_included=[]):
        super().__init__(values_to_be_included)


def main():
    spamfilter = SPAMFilter(["SPAM"])
    print(spamfilter.filter(["SPAM", "DAS", "IST", "SPAM", "SPAM", "DETECTED"]))

    namefilter = NameFilter(["MICHAEL", "SOPHIE"])
    print(namefilter.filter(["DAS", "SIND", "MICHAEL", "UND", "SOPHIE"]))


if __name__ == "__main__":
    main()
