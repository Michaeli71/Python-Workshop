mitglieder_liste = []

# TODO
