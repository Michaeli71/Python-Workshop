sample_names = ["TIM", "TOM", "MIKE", "JOHN", "MICHAEL", "STEFAN"]
# TODO

only_odd_length = []
print(only_odd_length)

only_even_length = [] # TODO
print(only_even_length)
