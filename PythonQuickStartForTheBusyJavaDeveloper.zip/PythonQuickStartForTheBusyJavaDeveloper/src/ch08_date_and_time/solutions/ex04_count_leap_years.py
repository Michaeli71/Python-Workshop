import calendar


def count_leap_years(start_year_incl, end_year_excl):
    count = 0
    for year in range(start_year_incl, end_year_excl):
        if calendar.isleap(year):
            count += 1
    return count


print(count_leap_years(2010, 2019))
print(count_leap_years(2000, 2019))


def count_leap_years_2(start_year_incl, end_year_excl):
    return sum([1 for year in range(start_year_incl, end_year_excl) if calendar.isleap(year)])


print(count_leap_years_2(2010, 2019))
print(count_leap_years_2(2000, 2019))
