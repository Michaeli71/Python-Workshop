import treepoem

img = treepoem.generate_barcode(
    barcode_type='qrcode',
    # data = 'https://github.com/Michaeli71/JAX-London-Best-of-Java-23',
    # data='https://github.com/Michaeli71/Python-For-Machine-Learning-2024/',
    # data='https://github.com/Michaeli71/Python-For-Machine-Learning-2025',
    # data='https://github.com/Michaeli71/Best-Of-Modern-Java-21-24-My-Favorite-Features',
    #data='https://github.com/Michaeli71/Fun-With-OpenAI-Using-Java-And-Python',
    #data="https://github.com/Michaeli71/JUGS-Best-of-Modern-Java-21-24",
    #data="https://github.com/Michaeli71/Best-Of-Java-17-25",
    #data="https://github.com/Michaeli71/JAX-London-Best-of-Java-17-25",
    #data="https://github.com/Michaeli71/Best-Of-Modern-Java-21-24-My-Favorite-Features",
    #data="https://github.com/Michaeli71/Best-Of-Modern-Java-21-25-My-Favorites",
    #data="https://github.com/Michaeli71/DesignPatternsInAction",
    #data="https://github.com/Michaeli71/JUGS-Best-of-Modern-Java-21-25",
    data="https://github.com/Michaeli71/Best-Of-Modern-Java-21-25-My-Favorite-Features",
    options={"eclevel": "Q"})

img.convert('1').save('Best-Of-Modern-Java-21-25-My-Favorite-Features.png')
