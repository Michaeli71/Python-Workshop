class PersonSurprise():
    def __init__(self, name, age, gender):
        self.name = name
        self.age = age
        self.gender = gender

    def __str__(self):
        return f"name: {self.name}, age: {self.age}, gender: {self.gender}"

    def __repr__(self):
        return f"name: {self.name}, age: {self.age}, gender: {self.gender}"

    def modifiy1(self):
        self.__delattr__("age")

    def modifiy2(self):
        self.__delattr__("gender")


def main():
    person = PersonSurprise("Surprise", 21, "Male")
    print(person)

    try:
        person.modifiy1()
        if not hasattr(person, "age"):
            print("NO AGE")
        print(person)
    except Exception as ex:
        print(ex)

    try:
        setattr(person, "age", 42)
        if  hasattr(person, "age"):
            print("HAS AGE")
        person.modifiy2()
        if not hasattr(person, "gender"):
            print("NO GENDER")
        print(person)
    except Exception as ex:
        print(ex)

    try:
        del person.name
        print(person)
    except Exception as ex:
        print(ex)

if __name__ == '__main__':
    main()