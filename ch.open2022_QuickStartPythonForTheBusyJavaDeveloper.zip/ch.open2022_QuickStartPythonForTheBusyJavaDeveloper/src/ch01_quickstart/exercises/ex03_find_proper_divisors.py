def find_proper_divisors(value):
    divisors = []
    # TODO
    return divisors


print(find_proper_divisors(12))