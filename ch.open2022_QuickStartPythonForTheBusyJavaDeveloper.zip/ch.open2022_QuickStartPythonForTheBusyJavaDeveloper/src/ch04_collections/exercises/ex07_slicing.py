values = [3, 4, 5, 8, 9]
print(values)

# hinzufüpgen
# TODO

# löschen
# TODO