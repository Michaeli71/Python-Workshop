numbers = [11, 2, 3, 4, 5, 6, 7, 8, 9]

print("len:", len(numbers))
print("min:", min(numbers))
print("max:", max(numbers))
print("sum:", sum(numbers))

numbers.reverse()
print("revserse:", numbers)
numbers.sort()
print("sort:", numbers)

