def even_generator():
    # TODO
    pass

def odd_generator():
    # TODO
    pass


for i in even_generator():
    print(i)
    if i > 10:
        break


for i in odd_generator():
    print(i)
    if i > 10:
        break