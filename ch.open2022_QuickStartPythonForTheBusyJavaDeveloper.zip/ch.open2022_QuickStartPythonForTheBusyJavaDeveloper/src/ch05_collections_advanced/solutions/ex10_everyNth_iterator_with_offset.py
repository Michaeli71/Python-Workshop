class EveryNthWithOffset:
    def __init__(self, values, step, offset=0):
        self.values = values
        self.pos = offset
        self.step = step

    def __iter__(self):
        return self

    def __next__(self):
        if self.pos >= len(self.values):
            raise StopIteration

        self.pos += self.step
        return self.values[self.pos - self.step]


second_list = EveryNthWithOffset([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3)
print(list(second_list))

second_list = EveryNthWithOffset([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3, 2)
print(list(second_list))