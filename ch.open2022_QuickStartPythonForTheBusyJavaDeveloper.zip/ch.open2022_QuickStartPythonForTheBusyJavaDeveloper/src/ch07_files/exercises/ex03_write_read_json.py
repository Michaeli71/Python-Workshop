data = {"LARRY": {
    'name': 'Larry',
    'website': 'google.com',
    'from': 'Michigan'
}, "TIM": {
    'name': 'Tim',
    'website': 'apple.com',
    'from': 'California'
}, "MIKE": {
    'name': 'Mike',
    'website': 'JavaProfi.com',
    'from': 'Zurich'
}
}

# TODO
