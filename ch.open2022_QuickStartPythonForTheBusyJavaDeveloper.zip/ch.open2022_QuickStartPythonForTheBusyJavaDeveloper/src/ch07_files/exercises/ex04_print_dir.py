# TODO
files = []

for current in files:
    # TODO
    pass
